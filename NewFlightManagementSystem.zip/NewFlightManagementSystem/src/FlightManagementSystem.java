import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FlightManagementSystem extends JFrame implements ActionListener {
    private final JButton employeeButton;
    private final JButton managerButton;
    private final JButton administratorButton;

    public FlightManagementSystem() {
        super("Flight Management System for Corporates");
        setLayout(new GridLayout(4, 1));

        JLabel welcomeLabel = new JLabel("Flight Management System for Corporates");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));  // Set the font size and style
        welcomeLabel.setForeground(Color.BLUE);  // Set the text color
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(welcomeLabel);

        employeeButton = new JButton("Employee Login");
        employeeButton.addActionListener(this);
        add(employeeButton);

        managerButton = new JButton("Manager Login");
        managerButton.addActionListener(this);
        add(managerButton);

        administratorButton = new JButton("Administrator Login");
        administratorButton.addActionListener(this);
        add(administratorButton);

        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        getContentPane().setBackground(Color.YELLOW);  // Set the background color to yellow
        setLocationRelativeTo(null);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static class Login extends JFrame{

        static JLabel l1,l2,l3;
        static JTextField t1;
        static JPasswordField t2;
        static JButton b1,b2;
        Login(){
            Font f= new Font("Arial",Font.BOLD,25);
            f.isItalic();
            l1=new JLabel("Login");
            l1.setFont(f);
            l2=new JLabel("Username");
            t1=new JTextField();
            l3=new JLabel("Password");
            t2=new JPasswordField();
            b1=new JButton("Submit");
            b2=new JButton("Back");
            l1.setBounds(60,40,200,40);
            l2.setBounds(60,100,100,20);
            t1.setBounds(60,120,200,30);
            l3.setBounds(60,170,100,20);
            t2.setBounds(60,190,200,30);
            b1.setBounds(60,250,200,30);
            b2.setBounds(60,300,200,30);
            add(l1);
            add(t1);
            add(l2);
            add(t2);
            add(l3);
            add(b1);
            add(b2);
            setLayout(null);
            setVisible(true);
            setSize(350,400);
            getContentPane().setBackground(Color.YELLOW);  // Set the background color to yellow
            LineBorder blackBorder = new LineBorder(new Color(218, 127, 9),7);
            getRootPane().setBorder(blackBorder);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == employeeButton) {
            Login Loginframe = new Login();
            setVisible(false);
            Login.l1.setText("Employee Login");
            Login.b1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                        String username = Login.t1.getText();
                        String password = Login.t2.getText();
                        Employee employee = getEmployee(username, password);
                        if (employee != null) {
                            Loginframe.setVisible(false);
                            Login.t1.setText("");
                            Login.t2.setText("");
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                            Login.t1.setText("");
                            Login.t2.setText("");
                            Loginframe.setVisible(true);
                        }
                    }
            });
            Login.b2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Loginframe.setVisible(false);
                    setVisible(true);
                }
            });
        } else if (e.getSource() == managerButton) {
            setVisible(false);
            Login Loginframe = new Login();
            setVisible(false);
            Login.l1.setText("Manager Login");
            Login.b1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    String username = Login.t1.getText();
                    String password = Login.t2.getText();
                    Manager manager = getManager(username, password);
                    if (manager != null) {
                        Loginframe.setVisible(false);
                        Login.t1.setText("");
                        Login.t2.setText("");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                        Login.t1.setText("");
                        Login.t2.setText("");
                        Loginframe.setVisible(true);
                    }
                }
            });
            Login.b2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Loginframe.setVisible(false);
                    setVisible(true);
                }
            });
        } else if (e.getSource() == administratorButton) {
            Login Loginframe = new Login();
            setVisible(false);
            Login.l1.setText("Admin Login");
            Login.b1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    String username = Login.t1.getText();
                    String password = Login.t2.getText();
                    Admin admin = getAdmin(username, password);
                    if (admin != null) {
                        Loginframe.setVisible(false);
                        Login.t1.setText("");
                        Login.t2.setText("");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                        Login.t1.setText("");
                        Login.t2.setText("");
                        Loginframe.setVisible(true);
                    }
                }
            });
            Login.b2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Loginframe.setVisible(false);
                    setVisible(true);
                }
            });
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////
    private Employee getEmployee(String username, String password) {
//        Login login = new Login();
        Employee employee = null;
        try {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            String sql = "SELECT * FROM employees WHERE username = ? AND password = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                setVisible(false);
                String name = rs.getString("name");
                int empId = rs.getInt("empId");
                employee = new Employee(name, empId, username, password);
                new EmployeePortal();
            }
            rs.close();
            pstmt.close();
            conn.close();
            jdbcConnector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return employee;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public class Employee {
        private String name;
        private static int empid;
        private String usname;
        private String pass;
        public Employee(String name,int empid,String usname, String pass) {
            this.name = name;
            this.empid = empid;
            this.usname = usname;
            this.pass = pass;
        }
        public String getName() {
            return name;
        }
        public static int getId(){
            return empid;
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////
    private Manager getManager(String username, String password) {
//        Login login = new Login();
        Manager manager = null;
        try {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            String sql = "SELECT * FROM managers WHERE username = '"+username+"' AND password = '"+password+"'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                setVisible(false);
                new ManagerPortal();
                String name = rs.getString("name");
                manager = new Manager(name, username, password);
            }
            rs.close();
            pstmt.close();
            conn.close();
            jdbcConnector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return manager;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public class Manager {
        private String name;
        private String usname;
        private String pass;
        public Manager(String name,String usname, String pass) {
            this.name = name;
            this.usname = usname;
            this.pass = pass;
        }
        public String getName() {
            return name;
        }
    }
    //(DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)(HOST=myOracle)(PORT=9999))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=ORADATA)))
    //////////////////////////////////////////////////////////////////////////////////////////////
    private Admin getAdmin(String username, String password) {
//        Login login = new Login();
        Admin admin = null;
        try {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            String sql = "SELECT * FROM admin WHERE username = '"+username+"' AND password = '"+password+"'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                setVisible(false);
                String name = rs.getString("name");
                admin = new Admin(name, username, password);
            }
            rs.close();
            pstmt.close();
            conn.close();
            jdbcConnector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return admin;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public class Admin {
        private String name;
        private String usname;
        private String pass;
        public Admin(String name,String usname, String pass) {
            this.name = name;
            this.usname = usname;
            this.pass = pass;
        }
        public String getName() {
            return name;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        new FlightManagementSystem();
    }
}